repeat task.wait() until game:IsLoaded()
print("Bedwarz fr fr")