repeat task.wait() until game:IsLoaded()
print("Voidware x Rivals")